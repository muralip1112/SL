import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddyourbussinessComponent } from './addyourbussiness.component';

describe('AddyourbussinessComponent', () => {
  let component: AddyourbussinessComponent;
  let fixture: ComponentFixture<AddyourbussinessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddyourbussinessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddyourbussinessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
