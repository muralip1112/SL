import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addyourbussiness',
  templateUrl: './addyourbussiness.component.html',
  styleUrls: ['./addyourbussiness.component.css']
})
export class AddyourbussinessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
